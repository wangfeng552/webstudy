var fs = require("fs");
var http = require("http");
var path = require("path");
var buf = new Buffer(1024);

var files = fs.readdirSync("./img/");
var imgPath = []; // 确定路径
var h = "";
files.forEach(function(x){
	imgPath.push("./img/"+x);
});

var po = function(file){
	return new Promise((resolve,reject) => {
		fs.open(file,"r",function(err,fd){
			fs.read(fd,buf,0,buf.length,0,function(err,bytes){
				if(err) {
					reject(err);
				}
				if(bytes > 0) {
					resolve(buf.slice(0, bytes).toString());
				}
			});
		});	
	});
}

po('./top.txt')
.then(
	data => {
		h += data;
		h += "var imgArr = [";
		for(var i=0;i<imgPath.length;i++) {
			
			if( i == (imgPath.length-1)) {
				h += "'"+imgPath[i]+"'";
			} else {
				h += "'"+imgPath[i]+"',";
			}
		}
		h += "];";
		h += "var imgObj = new Array();";
		h += "for(var i =0;i<imgArr.length;i++) {imgObj[i] = new Image();imgObj[i].src = imgArr[i];}"
		h += "window.onload = function(){document.querySelectorAll('img.yjz').forEach(function(x,y){x.src = imgObj[y].getAttribute('src');});}";
		h += "</script></head><body>";
		return po('./bottom.txt');
	},
	e => {
		console.log(e);
	}
)
.then(
	d => {
		for(var i=0;i<imgPath.length;i++) {
			h += "<div class='img-box'><img src class='yjz'></div>";
		}
		h += d;
		write(h);
	},
	e => {
		console.log(e);
	}
)
.catch(function(err){
	console.log(err);
});

function write(h){
	fs.writeFile("temp.html",h,function(err){
		if(!err) {
			console.log("写入成功");
			return;
		}
		console.log(err);
	})
}

/*fs.open("./top.txt","r",function(err,fd){
	fs.read(fd,buf,0,buf.length,0,function(err,bytes){
		if(err) {
			return;
		}
		console.log(bytes + " 字节被读取");
		if(bytes > 0) {
			h += buf.slice(0, bytes).toString();
			h += "var imgArr = "+imgPath+";";
			h += "var imgObj = new Array();";
			h += "for(var i =0;i<imgArr.length;i++) {imgObj[i] = new Image();imgObj[i].src = imgArr[i];}"
			h += "window.onload = function(){document.querySelectorAll('img.yjz').forEach(function(x,y){x.src = imgObj[y].getAttribute('src');});}";
			h += "</script></head><body>";
		}
		
	})
});

var hh = "";
for(var i=0;i<imgPath.length;i++) {
	hh += "<div class='img-box'><img src class='yjz'></div>";
}
// bottom  待定
fs.open("")*/
