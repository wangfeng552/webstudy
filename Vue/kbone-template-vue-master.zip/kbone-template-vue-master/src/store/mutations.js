export default {
  FAKE_MUTATION(state, input) {
    state.input = input
  }
}
