<template>
  <div class="footer">
    <p>wechat-miniprogram</p>
  </div>
</template>

<script>
export default {
  name: 'Footer',
}
</script>

<style lang="less">
.footer {
  margin-top: 10px;
  width: 100%;
  text-align: center;
}
</style>
